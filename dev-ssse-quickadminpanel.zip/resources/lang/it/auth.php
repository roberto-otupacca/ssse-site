<?php

return [
    'failed'   => 'Queste credenziali non corrispondono a nessuno dei nostri record.',
    'throttle' => 'Troppi tentativi di login. Riprovi in :seconds seconds.',
];
