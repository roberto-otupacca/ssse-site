<?php

return [
    'previous' => '« Precedente',
    'next'     => 'Successiva »',
];
