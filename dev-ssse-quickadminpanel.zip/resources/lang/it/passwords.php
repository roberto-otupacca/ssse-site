<?php

return [
    'password' => 'La password deve essere di almeno sei caratteri e coincidere con il campo di conferma.',
    'reset'    => 'La sua password è stata resettata!',
    'sent'     => 'Le abbiamo inviato un link per il reset della password tramite email!',
    'token'    => 'Il token per il reset della password non è valido.',
    'user'     => 'Non siamo in grado di trovare un utente con questo indirizzo email.',
    'updated'  => 'La password è stata cambiata!',
];
