<?php

return [
    'site_title' => 'SSSE',
];
